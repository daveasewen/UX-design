import { useState } from "react";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ChevronRight,
  Clock,
  AlertTriangle,
  CheckCircle,
  X,
  Building2,
  CreditCard,
  LayoutDashboard,
  FileText,
  Settings,
  LogOut,
  Menu,
} from "lucide-react";

const fmt = (n: number) =>
  "£" + n.toLocaleString("en-GB", { minimumFractionDigits: 0, maximumFractionDigits: 0 });

const HIGH_VALUE_THRESHOLD = 10_000;

const pendingItems = [
  {
    id: "p1",
    payee: "Amazon Business",
    amount: 4502,
    requestedBy: "Sarah Chen",
    daysAgo: 2,
    ref: "INV-2026-0441",
    sortCode: "20-••-••",
    accountNo: "••••••91",
  },
  {
    id: "p2",
    payee: "BrightHire Payroll Ltd",
    amount: 45200,
    requestedBy: "Sarah Chen",
    daysAgo: 2,
    ref: "PAY-MAY-2026",
    sortCode: "30-••-••",
    accountNo: "••••••67",
  },
];

const upcomingItems = [
  { id: "u1", date: "15 May 2026", payee: "Amazon Business", amount: 4502, category: "Supplier" },
  { id: "u2", date: "22 May 2026", payee: "BrightHire Payroll Ltd", amount: 45200, category: "Payroll" },
  { id: "u3", date: "22 Jul 2026", payee: "HMRC — PAYE", amount: 2200, category: "Tax" },
  { id: "u4", date: "12 Aug 2026", payee: "British Gas Business", amount: 4200, category: "Utilities" },
  { id: "u5", date: "09 Sep 2026", payee: "Ravenscroft Properties", amount: 50200, category: "Rent" },
];

const upcomingTotal = upcomingItems.reduce((s, i) => s + i.amount, 0);

type ModalState =
  | { type: "none" }
  | { type: "confirm"; item: (typeof pendingItems)[0] }
  | { type: "reject"; item: (typeof pendingItems)[0] }
  | { type: "approved"; item: (typeof pendingItems)[0] }
  | { type: "rejected"; item: (typeof pendingItems)[0] };

export default function App() {
  const [approved, setApproved] = useState<Set<string>>(new Set());
  const [rejected, setRejected] = useState<Set<string>>(new Set());
  const [modal, setModal] = useState<ModalState>({ type: "none" });
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleApprove = (item: (typeof pendingItems)[0]) => {
    setModal({ type: "confirm", item });
  };

  const handleReject = (item: (typeof pendingItems)[0]) => {
    setModal({ type: "reject", item });
  };

  const confirmApprove = () => {
    if (modal.type !== "confirm") return;
    setApproved((s) => new Set([...s, modal.item.id]));
    setModal({ type: "approved", item: modal.item });
  };

  const confirmReject = () => {
    if (modal.type !== "reject") return;
    setRejected((s) => new Set([...s, modal.item.id]));
    setModal({ type: "rejected", item: modal.item });
  };

  const closeModal = () => setModal({ type: "none" });

  const activePending = pendingItems.filter(
    (i) => !approved.has(i.id) && !rejected.has(i.id)
  );

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* ── Topbar ── */}
      <header className="bg-[#db0011] h-12 flex items-center px-6 gap-4 select-none">
        <button
          className="text-white/80 hover:text-white lg:hidden"
          onClick={() => setSidebarOpen((v) => !v)}
        >
          <Menu size={18} />
        </button>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-[3px]">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="w-2 h-2 rounded-full"
                style={{
                  background: i < 3 ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.45)",
                }}
              />
            ))}
          </div>
          <span className="text-white font-semibold text-base tracking-wide">HSBC</span>
          <span className="text-white/40 text-xs ml-1">Business Banking</span>
        </div>
        <div className="ml-auto flex items-center gap-6 text-white/75 text-sm">
          <span className="hidden sm:block">Meridian Tech Solutions Ltd</span>
          <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-white text-xs font-medium">
            JR
          </div>
        </div>
      </header>

      <div className="flex min-h-[calc(100vh-48px)]">
        {/* ── Sidebar ── */}
        <aside
          className={`${
            sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
          } fixed lg:static z-30 top-12 left-0 h-[calc(100vh-48px)] w-56 bg-white border-r border-border flex flex-col transition-transform duration-200`}
        >
          <nav className="flex-1 py-6 px-3 space-y-0.5 text-sm">
            {[
              { icon: LayoutDashboard, label: "Overview" },
              { icon: CreditCard, label: "Payments", active: true },
              { icon: ArrowDownLeft, label: "Receipts" },
              { icon: Building2, label: "Accounts" },
              { icon: FileText, label: "Statements" },
            ].map(({ icon: Icon, label, active }) => (
              <button
                key={label}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-left transition-colors ${
                  active
                    ? "bg-[#111111] text-white font-medium"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <Icon size={15} />
                {label}
              </button>
            ))}
          </nav>
          <div className="border-t border-border px-3 py-4 space-y-0.5 text-sm">
            <button className="w-full flex items-center gap-3 px-3 py-2.5 text-left text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors">
              <Settings size={15} />
              Settings
            </button>
            <button className="w-full flex items-center gap-3 px-3 py-2.5 text-left text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors">
              <LogOut size={15} />
              Sign out
            </button>
          </div>
        </aside>

        {/* overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/20 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* ── Main ── */}
        <main className="flex-1 min-w-0 px-6 lg:px-10 py-8 space-y-8">
          {/* Page heading */}
          <div className="flex items-baseline justify-between gap-4">
            <div>
              <h1 className="text-xl font-semibold tracking-tight">Payments</h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                Meridian Tech Solutions Ltd · as of 12 May 2026
              </p>
            </div>
            <button className="hidden sm:flex items-center gap-2 bg-[#111111] text-white text-sm px-4 py-2 hover:bg-[#333333] transition-colors">
              <ArrowUpRight size={14} />
              New payment
            </button>
          </div>

          {/* ── Cash Position ── */}
          <section>
            <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-widest mb-3">
              Cash position
            </h2>
            <div className="bg-card border border-border">
              {/* Top row: main figures */}
              <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-y lg:divide-y-0 divide-border">
                <div className="p-5 lg:p-6">
                  <p className="text-xs text-muted-foreground mb-1">Opening balance</p>
                  <p
                    className="text-2xl font-light tracking-tight"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    {fmt(120000)}
                  </p>
                </div>
                <div className="p-5 lg:p-6">
                  <p className="text-xs text-muted-foreground mb-1">Current balance</p>
                  <p
                    className="text-2xl font-semibold tracking-tight"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    {fmt(122450)}
                  </p>
                </div>
                <div className="p-5 lg:p-6">
                  <p className="text-xs text-muted-foreground mb-1">Net movement today</p>
                  <p
                    className="text-2xl font-light tracking-tight text-[#1a7a3c]"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    +{fmt(2450)}
                  </p>
                </div>
                <div className="p-5 lg:p-6">
                  <p className="text-xs text-muted-foreground mb-1">Est. closing balance</p>
                  <p
                    className="text-2xl font-light tracking-tight"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    {fmt(124000)}
                  </p>
                </div>
              </div>
              {/* Bottom row: inflows / outflows */}
              <div className="border-t border-border grid grid-cols-2 divide-x divide-border bg-secondary/40">
                <div className="px-5 lg:px-6 py-3 flex items-center gap-2">
                  <ArrowDownLeft size={14} className="text-[#1a7a3c]" />
                  <span className="text-xs text-muted-foreground">Inflows today</span>
                  <span
                    className="ml-auto text-sm font-medium text-[#1a7a3c]"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    +{fmt(11650)}
                  </span>
                </div>
                <div className="px-5 lg:px-6 py-3 flex items-center gap-2">
                  <ArrowUpRight size={14} className="text-[#6a6a6a]" />
                  <span className="text-xs text-muted-foreground">Outflows today</span>
                  <span
                    className="ml-auto text-sm font-medium text-foreground"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    −{fmt(9200)}
                  </span>
                </div>
              </div>
            </div>

            {/* Coverage notice */}
            <div className="mt-3 bg-white border border-border px-5 py-3 flex items-start gap-3">
              <CheckCircle size={15} className="text-[#1a7a3c] mt-0.5 shrink-0" />
              <p className="text-sm text-foreground leading-relaxed">
                Covered through May.{" "}
                <span className="text-muted-foreground">
                  Current balance {fmt(122450)} minus May scheduled payments {fmt(49702)} leaves a{" "}
                  <strong className="text-foreground font-medium">{fmt(72748)} buffer</strong>.
                </span>
              </p>
            </div>
          </section>

          {/* ── Pending Approvals ── */}
          <section>
            <div className="flex items-baseline justify-between mb-3">
              <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-widest">
                Pending approval
              </h2>
              {activePending.length > 0 && (
                <span className="text-xs text-muted-foreground">{activePending.length} item{activePending.length !== 1 ? "s" : ""} awaiting action</span>
              )}
            </div>

            {activePending.length === 0 ? (
              <div className="bg-card border border-border px-5 py-6 text-sm text-muted-foreground text-center">
                No payments pending approval.
              </div>
            ) : (
              <div className="space-y-px">
                {activePending.map((item) => {
                  const isHighValue = item.amount >= HIGH_VALUE_THRESHOLD;
                  return (
                    <div
                      key={item.id}
                      className="bg-card border border-border px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-4"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-sm">{item.payee}</span>
                          {isHighValue && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#8a5500] bg-[#fff4e0] border border-[#f0d080] px-1.5 py-0.5">
                              <AlertTriangle size={10} />
                              High value
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1">
                          <span className="text-xs text-muted-foreground">
                            Ref: {item.ref}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            Sort code {item.sortCode} · Account {item.accountNo}
                          </span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock size={10} />
                            Requested by {item.requestedBy}, {item.daysAgo}d ago
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 sm:gap-6">
                        <span
                          className="text-base font-semibold tabular-nums"
                          style={{ fontVariantNumeric: "tabular-nums" }}
                        >
                          {fmt(item.amount)}
                        </span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleReject(item)}
                            className="text-sm px-4 py-1.5 border border-border text-muted-foreground hover:border-[#db0011] hover:text-[#db0011] transition-colors"
                          >
                            Decline
                          </button>
                          <button
                            onClick={() => handleApprove(item)}
                            className="text-sm px-4 py-1.5 bg-[#111111] text-white hover:bg-[#333333] transition-colors"
                          >
                            Approve
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Show resolved items */}
            {[...approved, ...rejected].size > 0 && (
              <div className="mt-2 space-y-px">
                {pendingItems
                  .filter((i) => approved.has(i.id) || rejected.has(i.id))
                  .map((item) => {
                    const isApproved = approved.has(item.id);
                    return (
                      <div
                        key={item.id}
                        className="bg-secondary/40 border border-border px-5 py-3 flex items-center gap-4 opacity-60"
                      >
                        <span className="flex-1 text-sm text-muted-foreground">{item.payee}</span>
                        <span
                          className="text-sm tabular-nums text-muted-foreground"
                          style={{ fontVariantNumeric: "tabular-nums" }}
                        >
                          {fmt(item.amount)}
                        </span>
                        <span
                          className={`text-xs font-medium px-2 py-0.5 ${
                            isApproved
                              ? "text-[#1a7a3c] bg-[#e6f4eb]"
                              : "text-[#db0011] bg-[#fde8e8]"
                          }`}
                        >
                          {isApproved ? "Approved" : "Declined"}
                        </span>
                      </div>
                    );
                  })}
              </div>
            )}
          </section>

          {/* ── Upcoming Payments ── */}
          <section>
            <div className="flex items-baseline justify-between mb-3">
              <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-widest">
                Upcoming payments
              </h2>
              <span className="text-xs text-muted-foreground">5 scheduled</span>
            </div>

            <div className="bg-card border border-border">
              {/* Table header */}
              <div className="grid grid-cols-[1fr_auto_auto] sm:grid-cols-[140px_1fr_auto_auto] gap-x-4 px-5 py-2.5 border-b border-border bg-secondary/40">
                <span className="hidden sm:block text-[11px] font-medium text-muted-foreground uppercase tracking-wide">
                  Date
                </span>
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide">
                  Payee
                </span>
                <span className="hidden sm:block text-[11px] font-medium text-muted-foreground uppercase tracking-wide">
                  Category
                </span>
                <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wide text-right">
                  Amount
                </span>
              </div>

              {/* Rows */}
              {upcomingItems.map((item, idx) => (
                <div
                  key={item.id}
                  className={`grid grid-cols-[1fr_auto_auto] sm:grid-cols-[140px_1fr_auto_auto] gap-x-4 items-center px-5 py-3.5 hover:bg-secondary/30 transition-colors cursor-pointer group ${
                    idx < upcomingItems.length - 1 ? "border-b border-border" : ""
                  }`}
                >
                  <span
                    className="hidden sm:block text-sm text-muted-foreground"
                    style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "12.5px" }}
                  >
                    {item.date}
                  </span>
                  <div className="min-w-0">
                    <span className="text-sm font-medium truncate block">{item.payee}</span>
                    <span
                      className="sm:hidden text-xs text-muted-foreground"
                      style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "11px" }}
                    >
                      {item.date}
                    </span>
                  </div>
                  <span className="hidden sm:block text-xs text-muted-foreground bg-secondary px-2 py-0.5 self-center">
                    {item.category}
                  </span>
                  <div className="flex items-center gap-2 justify-end">
                    <span
                      className="text-sm font-medium"
                      style={{ fontVariantNumeric: "tabular-nums" }}
                    >
                      {fmt(item.amount)}
                    </span>
                    <ChevronRight
                      size={13}
                      className="text-muted-foreground/40 group-hover:text-muted-foreground transition-colors"
                    />
                  </div>
                </div>
              ))}

              {/* Total */}
              <div className="border-t-2 border-border grid grid-cols-[1fr_auto] sm:grid-cols-[140px_1fr_auto_auto] gap-x-4 px-5 py-3.5 bg-secondary/40">
                <span className="hidden sm:block" />
                <span className="text-sm font-medium text-muted-foreground">Total scheduled</span>
                <span className="hidden sm:block" />
                <span
                  className="text-sm font-semibold text-right"
                  style={{ fontVariantNumeric: "tabular-nums" }}
                >
                  {fmt(upcomingTotal)}
                </span>
              </div>
            </div>
          </section>

          <div className="h-4" />
        </main>
      </div>

      {/* ── Confirmation Modal ── */}
      {(modal.type === "confirm" || modal.type === "reject" || modal.type === "approved" || modal.type === "rejected") && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/30"
          onClick={(e) => e.target === e.currentTarget && closeModal()}
        >
          <div className="bg-white border border-border w-full max-w-md mx-4 shadow-xl">
            {/* Modal: Approve confirm */}
            {modal.type === "confirm" && (
              <>
                <div className="flex items-start justify-between px-6 pt-5 pb-4 border-b border-border">
                  <div>
                    <h3 className="text-base font-semibold">Confirm payment approval</h3>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      Review details before authorising
                    </p>
                  </div>
                  <button
                    onClick={closeModal}
                    className="text-muted-foreground hover:text-foreground mt-0.5"
                  >
                    <X size={16} />
                  </button>
                </div>
                <div className="px-6 py-5 space-y-3">
                  {modal.item.amount >= HIGH_VALUE_THRESHOLD && (
                    <div className="flex items-start gap-2 bg-[#fff4e0] border border-[#f0d080] px-3 py-2.5 text-sm text-[#7a4d00]">
                      <AlertTriangle size={14} className="mt-0.5 shrink-0" />
                      <span>
                        This payment exceeds {fmt(HIGH_VALUE_THRESHOLD)}. Verify with your authorised
                        contact before approving.
                      </span>
                    </div>
                  )}
                  <table className="w-full text-sm">
                    <tbody className="divide-y divide-border">
                      {[
                        ["Payee", modal.item.payee],
                        ["Amount", fmt(modal.item.amount)],
                        ["Reference", modal.item.ref],
                        ["Sort code", modal.item.sortCode],
                        ["Account number", modal.item.accountNo],
                        ["Requested by", modal.item.requestedBy],
                      ].map(([label, value]) => (
                        <tr key={label}>
                          <td className="py-2 text-muted-foreground w-36">{label}</td>
                          <td
                            className="py-2 font-medium"
                            style={
                              label === "Amount"
                                ? { fontVariantNumeric: "tabular-nums" }
                                : {}
                            }
                          >
                            {value}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="px-6 pb-5 flex gap-3 justify-end">
                  <button
                    onClick={closeModal}
                    className="px-5 py-2 text-sm border border-border text-muted-foreground hover:border-foreground hover:text-foreground transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmApprove}
                    className="px-5 py-2 text-sm bg-[#111111] text-white hover:bg-[#333333] transition-colors"
                  >
                    Confirm approval
                  </button>
                </div>
              </>
            )}

            {/* Modal: Reject confirm */}
            {modal.type === "reject" && (
              <>
                <div className="flex items-start justify-between px-6 pt-5 pb-4 border-b border-border">
                  <div>
                    <h3 className="text-base font-semibold">Decline payment</h3>
                    <p className="text-sm text-muted-foreground mt-0.5">
                      This will notify the requestor
                    </p>
                  </div>
                  <button onClick={closeModal} className="text-muted-foreground hover:text-foreground mt-0.5">
                    <X size={16} />
                  </button>
                </div>
                <div className="px-6 py-5">
                  <p className="text-sm text-foreground">
                    Decline <strong>{modal.item.payee}</strong> — {fmt(modal.item.amount)}?
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Sarah Chen will be notified and the payment request will be closed.
                  </p>
                </div>
                <div className="px-6 pb-5 flex gap-3 justify-end">
                  <button
                    onClick={closeModal}
                    className="px-5 py-2 text-sm border border-border text-muted-foreground hover:border-foreground hover:text-foreground transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmReject}
                    className="px-5 py-2 text-sm bg-[#db0011] text-white hover:bg-[#b5000d] transition-colors"
                  >
                    Decline payment
                  </button>
                </div>
              </>
            )}

            {/* Modal: Success */}
            {(modal.type === "approved" || modal.type === "rejected") && (
              <>
                <div className="px-6 pt-8 pb-6 text-center space-y-3">
                  {modal.type === "approved" ? (
                    <CheckCircle size={32} className="text-[#1a7a3c] mx-auto" />
                  ) : (
                    <X size={32} className="text-muted-foreground mx-auto" />
                  )}
                  <h3 className="text-base font-semibold">
                    {modal.type === "approved" ? "Payment approved" : "Payment declined"}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {modal.type === "approved"
                      ? `${modal.item.payee} — ${fmt(modal.item.amount)} has been approved and queued for processing.`
                      : `The request from Sarah Chen for ${modal.item.payee} has been declined.`}
                  </p>
                </div>
                <div className="px-6 pb-6 flex justify-center">
                  <button
                    onClick={closeModal}
                    className="px-6 py-2 text-sm bg-[#111111] text-white hover:bg-[#333333] transition-colors"
                  >
                    Close
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
