
  # Business Banking Payments Screen

  This is a code bundle for Business Banking Payments Screen. The original project is available at https://www.figma.com/design/PwG8V3SFZ0TPzP3rNxbrwS/Business-Banking-Payments-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  