---
name: ADS-grill-me
description: Grill the brief before anything gets built — six standard questions that decide how a piece of Apollo work will look (theme first, then light/dark, density, brand assets, data and constraints), then open discovery, one question at a time, until the brief is exhausted. Saves the answers as a short brief the other Apollo skills read. Use at the start of a new design project or a new design task, and always before ADS-generate-from-canon builds anything, whenever briefs/ holds no current brief for that task. Use this on openings like “new design project”, “I’m starting a new screen”, “make this look like our brand”, “use our brand colours”, “which theme should we use”, “what do you need from me before you build”, “here’s a new product area” — and skip it, silently, when a current brief already exists.
---

# Grill me

Two movements, at the start of the work. First, **six standard questions** — about two
minutes, and they decide things that are expensive to change later; the first of them
decides whether your corners are round. Then, **discovery**: keep asking, one question at
a time, until the brief is exhausted — until there is nothing material left that the
build would otherwise have to guess. There is no fixed number of discovery questions,
deliberately: a cap would end the questioning at the cap, not at the brief.

Skip any of them. Skip all of them. What this skill will **not** do is quietly pick for
you and say nothing: a skipped question is written down as *skipped*, and where a default
has to be used it is said out loud before anything is built.

## When to run this

**Look in `briefs/` before you ask anything.** That folder is the trigger, not the shape
of the request. If it already holds a current brief for the task in hand, **this skill is
finished — do not ask the six questions, do not mention them, get on with the work.** A
grill that re-fires on every prompt is one a designer turns off within the hour, and they
turn off everything else with it.

Run it when the folder gives you no answer:

- At the start of a **new design project** — `briefs/` is empty or does not exist.
- At the start of a **new design task** inside a project that already has briefs, when the
  task is different enough to want its own answers (a different product area, a different
  audience, a different surface) and no brief covers it.
- **Before `ADS-generate-from-canon` builds anything**, when no current brief exists. That
  skill checks for a brief first and will ask the theme question itself if it can't find
  one — running this properly is the better version of that.

A brief is **current** when it covers the task being asked for. Age alone does not retire
one; a different task does. When it is genuinely unclear whether an existing brief covers
this work, ask that single question — *"there's a brief from Tuesday for the payments
area; does this belong to it?"* — rather than re-running all six.

## How to skip

| you say | what happens |
|---|---|
| *"skip the grill"* / *"skip all"* | No more questions. Every answer is recorded as `skipped`. The theme default is **announced** before the build starts. |
| *"skip"* on a single question | That one is recorded as `skipped`. The next question is asked. |
| nothing, or a shrug | Treated as a skip on that question. Never as agreement. |

A skipped question is not a wrong answer. It is a decision left open, and it stays
visible in the brief so it can be closed later instead of being discovered as a surprise
in the work.

## The six questions

Ask them **in this order**, one at a time, and stop asking as soon as a full skip is
called. Keep each one to the question plus its choices — do not stack them into a wall.

---

### 1. Which theme? *(ask this first — it changes the shape of everything)*

Four ship. They differ in colour and, crucially, in **corner shape**:

| theme | what you'll see |
|---|---|
| **Mono** | Monochrome throughout — colour appears only in status and in charts. **Square: every corner is zero radius, deliberately.** |
| **Common** *(code key: `legacy`)* | The established interface look, brand red and teal in the interactive parts. Square corners. |
| **Console** | Mono's neutrals with the brand palette on top, and the one theme with **rounded corners** — controls and surfaces both. |
| **Supercharge** | The brand-uplift look, on its own warmer neutral range. Square corners; status and chart colour identical to Mono. |

Say the theme name. If you're not sure, say what the product feels like and the choice
can be narrowed for you.

**If this one is skipped:** the build will use **Mono**, and it will say so before it
starts — in Mono every corner is square by design, so a page that looks flatter than you
expected is the theme, not a mistake. Changing the theme afterwards is one attribute, but
anything hand-adjusted around square corners has to be revisited.

---

### 2. Light, dark, or both?

Both is the usual answer and costs nothing at build time — every component ships both.
Answer "light only" or "dark only" if the product genuinely never offers the other, so
the work isn't checked against a mode nobody will see.

---

### 3. How dense, and how wide?

Two halves of one question:

- **Density** — comfortable (roomy, fewer things visible) or compact (more on screen, for
  people who live in this all day).
- **Width** — the surface you're designing for: phone, tablet, laptop, wide desktop, or a
  fixed maximum width you already work to.

---

### 4. Are there brand assets to use?

Logos, a photography set, product names, an existing colour a stakeholder will insist on,
a typeface that is already decided. Name them and say where they are. "None" and "not yet"
are both real answers — "not yet" is the one worth writing down.

---

### 5. Real data or placeholder?

- **Real** — you have actual content, figures or copy to use. Say where it is.
- **Placeholder** — invented content is fine for now.

This matters more than it sounds: real names, real currency amounts and real edge cases
change the layout, and a design that only ever held tidy placeholder text tends to break
the first time it meets a long one.

---

### 6. Anything fixed, or anything off-limits?

Both halves, in one answer:

- **Fixed** — accessibility commitments you have to meet (a contrast level above the
  default, no motion, keyboard-only operation, screen-reader specifics), regulatory or
  legal requirements, a pattern the organisation mandates.
- **Off-limits** — anything you want the system **not** to do. Common ones: don't invent
  components, don't add animation, don't touch the navigation, don't produce React, don't
  restructure content, don't get creative with colour.

Say them plainly. This is the question that saves the most rework.

---

## Then exhaust the brief — discovery

The six questions cover how the work will *look*. Discovery covers what the work *is*,
and it is the half that finds the things nobody thought to say. After question six (or
after a partial skip), keep going:

- **One question at a time.** Never a list, never a form. Each answer is allowed to
  change what you ask next — that is the point of asking one at a time.
- **Each question must earn its place.** Ask it only if the answer would change what gets
  built: who is this for and what do they do with it? what's the one thing it must make
  obvious? what happens when the numbers are bad? what does the user do next? is there an
  existing screen this replaces, and what was wrong with it? what's the worst real content
  this has to survive?
- **The stopping test:** could you now state every choice the build is about to make,
  precisely, without guessing? While the answer is no, there is still a question worth
  asking. When the answer is yes, **stop** — an exhausted brief is the goal, not a long
  interrogation. Say you're done and read the brief back in a few lines.
- **The skip hatch never closes.** *"That's enough"*, *"just build it"*, or a shrug ends
  discovery on the spot, recorded as `discovery ended by designer after N questions` —
  and everything already answered still counts.

## Save the answers

Write the answers to a small file in the project:

```
briefs/<YYYY-MM-DD>-<task-slug>-grill.md
```

e.g. `briefs/2026-08-30-payments-dashboard-grill.md`. Create `briefs/` if it isn't there.

Use the shape in `brief-template.md`, beside this file. Rules for it:

- **One line per answer.** It is a note, not a document.
- **Every one of the six appears**, in order, including the skipped ones — written as
  `skipped` with the date, so a gap is visible rather than absent.
- **Discovery gets its own short section** below the six: one line per question-and-answer,
  in the order asked, ending with either `brief exhausted` or `discovery ended by designer
  after N questions`. This section is where most of a build's judgment calls get their
  provenance.
- **Record what was actually said**, in the designer's own words where they said
  something specific. Don't tidy an answer into a category it didn't quite fit.
- **If the theme was skipped**, the brief records `skipped — proceeding with Mono
  (announced <date>)`, so the default is on the record as a default and not as a choice.

Then say, in one line, what you're about to build with — the theme, the modes, and any
constraint from question 6 — and start.

## Handing it on

`ADS-generate-from-canon` reads the newest brief in `briefs/` and **cites it** in its
used/missing note: which brief, and which of the six answers actually shaped the build.
A brief nobody cited is a brief nobody read.

**s258-D1 / s258-D2 (added, nothing above re-worded).** The build the brief hands on to is
**ambitious by default**: every control on the page is assumed to work, and the author writes
the JavaScript (the old "author no JS" rule 2a is removed). Two consequences for the grill.
Question 5, **data**, is now load-bearing rather than a nicety — the build needs entities,
currencies, a time span and enough rows for sorting and paging to mean something, so if it is
skipped, say what you will invent and how deep. And a skipped answer never licenses a dead
control: a shrug is still a yes, and the build wires it anyway.

When an answer changes mid-project, don't edit the old brief — run this again for the new
task and let the two sit side by side. The change is worth being able to see.

## Re-asking

Ask a single question again, out of order, whenever the work reaches something the brief
left open — "you skipped the data question and this table needs real amounts to lay out;
do you have any?" That is a good moment to ask, and a much better one than the start.

Don't re-run the whole grill on a project that already has a brief unless the designer
asks. Once is the point.

*Experimental — feedback on what's missing is the point.*
