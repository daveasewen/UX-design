---
name: ADS-generate-from-canon
description: Build a screen or component using only the Apollo design system — its 135 reviewed components, its tokens, its type composites and its layout rails — never inventing new ones. Flags anything the system is missing instead of improvising. Use when you want on-brand, accessible UI drafted by construction. Outputs React (preferred) or plain HTML/CSS. Use this whenever the thing being asked for IS a piece of UI, however casually it is put — “build me a dashboard”, “build a screen”, “make a page”, “design a settings page”, “create a form”, “mock up a view”, “add a card to this screen”, “put a table on that page”, “can you lay this out”.
---

# Generate from canon

Draft UI **strictly from the design system**. The one job here is to stop the common
failure of AI design work — quietly *inventing* components, variants or colours. If it
isn't in the system, this skill flags it rather than making it up.

This is the **strict** mode: deliberately faithful, not a creativity play. When the
system is genuinely missing something you need, use `ADS-draft-a-new-pattern`.

## Where things live

Four files answer almost every question. Go to them in this order.

| question | file |
|---|---|
| **What exists?** | `showroom/index.json` — 143 entries: 135 components + 8 foundations. Each carries `slug`, `name`, `aliases`, a one-line `blurb`, `level` (element / pattern / block / shell / template), `usage` group, `status` (stable / beta / deprecated), `related`, and its `page`. Search this by aliases and blurb, not by guessing a name. |
| **What does it look like?** | `showroom/<slug>.html` — the live page, every variant and state. `showroom/_thumbs/<slug>.png` for a glance. |
| **What is its contract?** | `knowledge/components/<slug>.meta.json` — `purpose`, `props` (with the token each prop `binds` to), `variants`, `tokens`, `relationships`, `accessibility`, `antiPatterns`, `provenance`. |
| **What is the real markup?** | `knowledge/snippets/<Slug>.reference.html` — the reviewed, gated source. Copy from here. Never re-draw a component from the picture. |

⚠ **Filenames are the index `slug`, but the capitalisation isn't consistent** between the
two folders — `summary` has `components/summary.meta.json` and
`snippets/Summary.reference.html`; `cta-lockup` has `snippets/CTA-lockup.reference.html`.
Match the slug **case-insensitively** (glob it) rather than guessing the case. Every one
of the 135 resolves that way.

Everything else: `knowledge/canon/canon.css` (all tokens, aliases, utilities and all 135
components), `knowledge/canon/type.css` (the type composites),
`knowledge/assets/icons/` (659 glyphs + `icons.manifest.json`),
`knowledge/guidelines/` (59 briefing notes; `_rules-index.json` indexes 470 rules from
them, each tagged BLOCKING / ADVISORY / REVIEW / TASTE),
`showroom/_foundations/` (grids, bento, logos, photography).

## Rules (non-negotiable)

1. **Only what exists.** Every component and variant comes from `showroom/index.json` /
   `knowledge/components/`. Missing what you need? Put it on a **Gaps** list and stop —
   never improvise a component or a variant.
2. **Copy the snippet, don't re-draw it.** Take markup and classes from
   `knowledge/snippets/<Slug>.reference.html`. Hand-rolling a component from its
   screenshot invents defects that the gates then catch as yours.
2a. **Copy the script address with the markup; author no JS.** Every snippet whose
    component carries behaviour declares its ADDRESS in `knowledge/components/<slug>.meta.json`
    (`behaviour.script`) and carries the same address in a `#behaviour-manifest` block beside
    `#token-manifest`. Take the snippet's own `<script>` (or its `AUTO-BEHAVIOUR` block)
    verbatim — the bytes are the key — and carry the address into the page's receipt. Never
    write a handler yourself, never paraphrase the script, never point at another component's
    script: shared behaviour is a registered partial. `fallback` says what the component does
    with JavaScript off; if it is null, say so in the Gaps list rather than inventing one.
    `_validate_receipt.py` reads the meta and checks the page loads what it names.
3. **Bind every visual value to a token by intent** — never a raw hex or px. The names
   live in `knowledge/tokens/*.json` and resolve in `knowledge/canon/canon.css`
   (`primary/background/hover` → `var(--primary-background-hover)`). Spacing, radius and
   border width are tokens too, not just colour: a raw px freezes the thing in every
   theme.
4. **Type via composites.** Component text takes a class from `knowledge/canon/type.css`
   — `.t-cm-*` for component text (button, label, caption, input, figure-1…6,
   chart-label, ctl-12/14/16), `.t-ed-*` for editorial (display-1/2, heading-1…4, body,
   body-small, caption). 31 in all. Never a raw `font-size` / `font-weight` /
   `line-height`.
5. **Pick a theme and say which.** Four ship: **mono** (the baseline), **common**,
   **console**, **supercharge** — the same four names the cold-start `DESIGN-CONTRACT.md`
   asks about, so the pack says back the name the designer said. (`legacy` is the older
   key for **common** and still resolves — `s227-D8` made the alias additive — but new
   work emits `common`.) Set them on the root element:
   `class="canon" data-apollo-theme="common" data-theme="light"`. The theme registry is
   `knowledge/tokens/themes/_themes.json`, and it records which colours belong to which
   theme. A colour from another theme's set is a leak, not a choice.
6. **Colour is meaning, and the reds are keyed to their background.**
   - Coloured red or green **text** exists in exactly one place: monetary values, always
     next to a symbol (minus, plus, up/down arrow). Nowhere else.
   - Two reds, chosen by the background behind them, not by light/dark mode: the dark red
     `#DA1A00` on **white**, the light red `#F6604C` on **everything else** — dark mode
     and every non-white ground alike.
   - Error checkboxes and radios take the red on the **mark only**. The label keeps
     default ink.
   - In mono, text and glyphs on an error surface take the default dark ink, both modes.
     White-on-error does not exist.
   - Ink itself is a token, not a literal — it resolves per theme (and it is never pure
     black). Bind to it; don't type a hex.
7. **Layout comes from the rails, not from taste.** For bento, grids and the layout
   dials, read **one file**: `knowledge/_render/_bento_edit_rails.json`. It carries every
   dial, its legal option set, the per-theme default, which options may be combined
   (chords) and which exclude each other. Generation ships the defaults — you do not have
   to decide anything up front. If a layout question isn't answered there, it's a Gap.
   Spacing picks from the ruled stops `{1, 2, 4, 16, 24, 40}`, never a free value.
7a. **Dashboards are bento-first, or you ask.** The rails are the *dial vocabulary*; this
    is the *layout choice*, and it is not yours to make silently. When the request is a
    dashboard — an overview, a landing screen, a wall of panels — say this, in your own
    reply, before you build:

    > **dashboard bento — is that right?**

    Then go bento-first unless the designer says otherwise. **A skip is a yes**, exactly
    as in `ADS-grill-me`: a shrug never counts as a no, and you never wait for permission to
    proceed. Bento-first means you **splice the snippet**, not re-draw the wall: start
    from `knowledge/snippets/Template-dashboard-bento.reference.html` and edit it down to
    the brief. Rule 2 applies here like everywhere else — hand-rolling a bento wall from
    `showroom/_foundations/bento.html` or straight from canon invents defects. The
    snippet's own scope is `.cn-template-dashboard-bento` over `.c-bento` /
    `.c-bento__grid` / `.c-bento__tile`; the dashboard role's dials read from
    `_bento_edit_rails.json`, and `showroom/_foundations/bento.html` stays the worked
    example you read, not the thing you copy.
    ⚠ **If the request is not dashboard-shaped and no template snippet fits, ask.** Do
    not reach for a template that is merely close, and do not compose a template's worth
    of screen out of loose components without saying that is what you are doing.
    <!-- W-333 (banked, #232): this routing step lives here for now. Its permanent home —
         routing off the knowledge graph rather than off a skill rule — is Dave's to rule. -->
    ⚠ `Template-dashboard.reference.html` is `.l-grid`-based, not bento. It is a
    legitimate non-bento dashboard and it is **not** the answer to "build me a dashboard"
    unless the designer answered the question above with a no.
7b. **Grouping comes from the graph, not from the class name.** Whether two modules share
    a group is a fact stored ONCE, as an `edges.groupsWith` entry in the member's
    `knowledge/components/<slug>.meta.json` (the positive twin of `mustNotNeighbour`). The
    rails' `grouping` dial and this rule are DERIVED from it and never restate it. A group is
    members that answer ONE question the user came with — never "the KPIs, because they are
    KPIs"; its members are uniform in kind, carry one accessible name and one containment
    signal, and stay contiguous at every band. Read the edge before you draw a `<section>`;
    where the edge is `ref:null` the grouping is undecided and is a Gap, not a guess. HOW MANY
    groups a screen has, and what belongs in each, is the designer's product decision — never
    yours (template-dashboard-bento.meta.json:12). The snippet's group classes are ROLE words
    (`tpl-group-lead` / `-evidence` / `-context`), never content types; the composition gate
    (`_validate_composition.py`, step 1b of `_validate_screen.py`) reads span legality off the
    page and blocks an orphan cell.
8. **Icons are real assets only** — from `knowledge/assets/icons/`. Never draw a glyph.
   If a shape is genuinely custom, mark it `<svg data-bespoke="why">` so it reads as a
   decision rather than an invention.
8a. **The mark is the masterbrand, and it is already bound.** Mastheads carry
    `knowledge/assets/logos/masterbrand-light-colour.svg` on light chrome and
    `masterbrand-dark-colour.svg` on dark. This is the DEFAULT and it needs no question —
    the shell and navigation snippets bind both files already, so rule 2 (copy the
    snippet) gets it right on its own. **Ask only when the brief names a different
    brand**, and then stop and treat it as a Gap: never re-key the mark, never set a
    wordmark in type, never draw one. The other ten files in `knowledge/assets/logos/`
    (hexagon, masterbrand-identifier, and the mono treatments) are chosen deliberately or
    not at all — `showroom/_foundations/logos.html` shows the set.
9. **Honour `antiPatterns` and `relationships`** from each component's meta —
   `mustNotNeighbour` in particular.
10. **Cover the states**: default / hover / pressed / focus / disabled / loading / error /
    empty, as the component defines them.
11. **Sentence case** for headings and labels. No ALL-CAPS outside acronyms.
12. **Carry provenance** — note which component and which tokens each part came from.

## Procedure

0. **Brief first.** Look for the newest `briefs/*-grill.md` in the project. If one
   exists, **read it and cite it** in the used/missing note — which brief, and which of
   its answers shaped the build (theme above all). If there is none, run the `ADS-grill-me`
   skill; if the designer would rather not, ask **one** question before you build —
   *which theme?* — because rule 5's four themes differ in corner shape as well as
   colour, and **mono makes every radius zero by design**, so a mono build is
   radius-blind: it cannot show you a shape decision you might have wanted. If the theme
   question is skipped too, **say which default you are using before you build** — mono,
   and square — and record it as a default, never as a choice. Never pick a theme
   silently.
1. **Find.** Search `showroom/index.json` for each thing the screen needs — by alias and
   blurb. Open the showroom page to confirm it's the right thing.
2. **Read the contract.** `knowledge/components/<slug>.meta.json` — variants, states,
   antiPatterns, relationships.
3. **Compose.** Link `knowledge/canon/canon.css` and `knowledge/canon/type.css`. Root
   element (or `<body>`) gets `class="canon"` plus **two** attributes — the theme and the
   mode: `data-apollo-theme="common|console|supercharge"` **and** `data-theme="light"` or
   `data-theme="dark"`. They are different dials and `canon.css` selects on both:
   `data-apollo-theme` carries the four themes, `data-theme` carries light/dark only.
   **The answer to step 0's theme question lands on `data-apollo-theme`.** `data-theme`
   has nowhere to put it, so a build that sets `data-theme` alone is a MONO build — and
   mono makes every radius token `0`. Mono is the attribute-less baseline: canon has no
   `data-apollo-theme="mono"` block, so mono is `data-theme` on its own (writing
   `data-apollo-theme="mono"` is legal and self-documenting — it simply selects nothing).
   Same contract as step 5 and as
   `knowledge/_RUNBOOK-compose-from-canon.md` § Compose a screen. (`data-mode` is a
   component-level attribute, not a theme one: in `canon.css` it appears only inside
   `.cn-template-auth`, swapping a light/dark logo mark. Do not put it on the root.) Drop each component in as
   its scope class + the snippet's own markup — `<div class="cn-button"><button class="btn
   primary">…</button></div>`. Use the `.c-*` layout utilities. **Your own `<style>` is
   harness only**: no hex, no redefining a `.c-*` or `.cn-*` class. If you're redefining a
   component locally, you've left canon.
   The long version of this is `knowledge/_RUNBOOK-compose-from-canon.md`.
4. **Gaps.** Anything the system can't supply → the Gaps list. Don't invent.
5. **Prove it.** Run the gates on what you built — see the `ADS-check-with-gates` skill.
   Composed screens have their own runner:
   `python3 knowledge/_validate_screen.py path/to/your-screen.html`.
   A draft you haven't gated is a claim, not a result.

## Output

- The code (React wiring the real components, or HTML/CSS on the canon classes).
- A short **used / missing** note: components and tokens drawn on, plus any Gaps.
- The gate verdict from step 5, as it actually printed.

> With Figma Dev Mode + Code Connect available you can pull components and variables
> live; otherwise the files above are the source of truth.

*Experimental — feedback on what's missing is the point.*
