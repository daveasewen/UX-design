# Apollo — Spider (v1.0.3), carrying Memento — Gumdrop

Apollo releases are named after the LUNAR MODULES, because they are the part that lands. Memento
is named after the COMMAND MODULES, because it is the part that navigates and remembers. This is
**Apollo — Spider**, and the clean cut of Memento inside it is **Memento — Gumdrop**. A release
takes one mission's whole pair: Spider and Gumdrop are both Apollo 9.

The working Apollo engine, plus a clean cut of Memento. Not a demo and not a summary: these are
the same tokens, component contracts, reference markup, canon CSS, gates, runbooks and library
the design system itself runs on. Build with it and see where you get to.

## Provenance — what this pack was baked from

| | |
|---|---|
| pack | `Apollo — Spider` |
| version | `v1.0.3` |
| carries | `Memento — Gumdrop v1.0.3` |
| commit | `1e028a1b5bf97d21e0135eb225376b12f8cfebee` |
| commit date | `2026-08-29T21:13:24+01:00` |
| manifest sha256 | `ea115bca7a219e65e222bd9ac2de99e3038f6a6707d3cc5c2591fd7f280a88ef` |
| files | 1648 |
| ruling | `s219-D8` (naming) · `s219-D5` (what ships) · `s219-D4` (the cut) |

Every file above came out of that commit via `git archive` — not out of anyone's working
directory. The ship list is `_MANIFEST.json`, which is generated, not hand-kept. Two builds of
the same commit against the same manifest produce a **byte-identical zip**, so any difference
between two packs is a real difference and can be audited.

## What is in here

- `skills/` — the five skills, at the root where you will find them. Four are written against
  this exact knowledge base; the fifth, `check-with-gates`, runs the packed gates on your work.
- `ci-template/` — a GitHub Actions workflow you copy into your own repo, the runner it calls,
  and a README saying what blocks and how to turn a check off honestly.
- `knowledge/tokens/` — every design token, plus the four theme override sets.
- `knowledge/components/` — one contract per component: props, variants, token bindings,
  states, anti-patterns, accessibility.
- `knowledge/snippets/` — the reviewed reference markup. This is what "correct" looks like.
- `knowledge/canon/` — canon.css and type.css, the composition layer, and the generators that
  mint them from tokens.
- `knowledge/compliance/` — which WCAG criteria apply to which component, and the rule set.
- `knowledge/_validate_*.py` — the gates. Each one in this pack was **run** outside the source
  repo before it was included; the verdicts are in `_MANIFEST.json`.
- `knowledge/_RUNBOOK-*.md` — the procedures: compose from canon, take a component through its
  gates, render and verify, write a criteria contract, onboard an existing code library.
- `showroom/` — the live library, including the foundations pages.
- `FIRST-SESSION.md` — **start here.** A guided first session with Memento: what it is in three
  sentences, then your first capture, your first ruling written through the machinery with every
  field explained, and your first wrap.
- `.github/` — the VS Code + Copilot bridge. `copilot-instructions.md` is loaded automatically
  and indexes the five skills with the phrases that should trigger each one; `prompts/` makes
  each skill a slash command. Without this the skills sit in the pack and never fire.
- `.vscode/settings.json` — the other half of that bridge: three Copilot settings that turn on
  the agent's debug-file log, which is where Copilot records **the server's own reported token
  usage for your session**. That is the session gauge, and until this cut the pack told you it
  did not exist. Reload the window once after unzipping.
  `memento-package/runbooks/_RUNBOOK-context-gauge.md` says how to read it, what the number
  means, and — just as important — what it must never be compared to.
- `memento-package/` — **Memento — Gumdrop v1.0.3**: Memento's machinery, plus the cold start.
  The machinery is the engine this design system runs on. The record it ships is **empty on
  purpose**: an empty task store, an empty rulings store — both with the shapes already right and
  driven against those shapes before shipping — and a starter `_CHAIN.md` that explains the
  first move and is replaced the first time you wrap. Nothing in it is anyone else's history.
  Your project grows its own memory from nothing, which is the point: the shapes are machinery,
  the contents are your record. Its version line is its own — this pack's version does not move
  it, and a later Apollo release may carry the same Gumdrop or a newer cut.
- `memento-package/_encoder-cache/` — the `cl100k_base` encoder data, vendored so token
  measurement works with no download and no environment variable. Its README says what it is,
  what it mirrors, its sha256 and its licence.

## The canon generators, and one warning

The generators that mint canon from the tokens are in here, because this is the working engine
and not a baked copy of one. Changing a token and re-minting canon can produce canon that never
passed a gate. Each generator says so when you run it inside this pack and asks you to pass
`--i-understand` before it will proceed. Then run `python3 ci-template/run-gates.py` — that
is what tells you whether what you just minted still passes.

## What is deliberately NOT in here

Review files, session notes, run logs, client project work, and the licensed material we cannot
redistribute. `_MANIFEST.json` lists every exclusion with its reason.

## What you need installed

`pip install tiktoken` — the only one, and it is RECOMMENDED rather than required: the pack
carries its own exact encoder for machines that cannot install it. `FIRST-SESSION.md` § Before you
start says why: the chain generator counts tokens exactly and REFUSES to write the file at all on
an estimate — with `tiktoken` it does that faster, without it the pack's own engine does it.

**The pack also carries its own encoder.** `memento-package/machinery/_encoder_home.py` contains a
pure-Python `cl100k_base` implementation — the same pretokenizer, the same byte-pair merges, over
the same vendored data — which runs when `tiktoken` cannot be imported and NAMES ITSELF when it
does (`purepy cl100k_base (exact, equality-gated)`, never the real library's name). It is exact,
not an estimate, and the pack ships the gate that proves it:

    python3 memento-package/machinery/_encoder_home.py --equality-gate

which drives both encoders over this pack's own text and refuses on the first token they disagree
about. It is a few times slower, which is why `tiktoken` is still the recommended path.

**You do not need network access for the encoder itself.** `tiktoken` normally downloads its
`cl100k_base` encoding data from `openaipublic.blob.core.windows.net`, which is blocked on many
corporate laptops. That data ships inside this pack instead, at
`memento-package/_encoder-cache/` (see the README beside it), and
`memento-package/machinery/_encoder_home.py` — the one place that knows where it is — points
`tiktoken` at it automatically, by `setdefault`, so your own `TIKTOKEN_CACHE_DIR` still wins.
Only the `tiktoken` **wheel** still comes from PyPI. Check the whole path in one command:

    python3 memento-package/machinery/_encoder_home.py --check

If the vendored data is ever missing or damaged, that check and the chain generator both refuse
loudly and name the file — there is no estimate fallback and never a silently wrong number.

A few gates additionally drive a real browser and need `playwright`. They are included, they are
not in the default run, and they name their own dependency when you run them without it — a
`COULD-NOT-ASK:` line and exit 77, which does not fail the build. See `_MANIFEST.json` for
which ones.
