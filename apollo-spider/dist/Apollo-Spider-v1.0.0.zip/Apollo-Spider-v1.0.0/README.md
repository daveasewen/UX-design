# Apollo — Spider (v1.0.0), carrying Memento — Gumdrop

Apollo releases are named after the LUNAR MODULES, because they are the part that lands. Memento
is named after the COMMAND MODULES, because it is the part that navigates and remembers. This is
**Apollo — Spider**, and the clean cut of Memento inside it is **Memento — Gumdrop**. A release
takes one mission's whole pair: Spider and Gumdrop are both Apollo 9.

The working Apollo engine, plus a clean cut of Memento. Not a demo and not a summary: these are
the same tokens, component contracts, reference markup, canon CSS, gates, runbooks and library
the design system itself runs on. Build with it and see where you get to.

## Provenance — what this pack was baked from

| | |
|---|---|
| pack | `Apollo — Spider` |
| version | `v1.0.0` |
| carries | `Memento — Gumdrop v1.0.0` |
| commit | `2f7c47bb904bd55c6ce94d0fecd81711bc79c5e4` |
| commit date | `2026-08-26T19:37:29+01:00` |
| manifest sha256 | `a8c3c961fc7223297025fbfc4bcc39801be5fb781a438cf0abd99f40bccc4df1` |
| files | 1610 |
| ruling | `s219-D8` (naming) · `s219-D5` (what ships) · `s219-D4` (the cut) |

Every file above came out of that commit via `git archive` — not out of anyone's working
directory. The ship list is `_MANIFEST.json`, which is generated, not hand-kept. Two builds of
the same commit against the same manifest produce a **byte-identical zip**, so any difference
between two packs is a real difference and can be audited.

## What is in here

- `skills/` — the five skills, at the root where you will find them. Four are written against
  this exact knowledge base; the fifth, `check-with-gates`, runs the packed gates on your work.
- `ci-template/` — a GitHub Actions workflow you copy into your own repo, the runner it calls,
  and a README saying what blocks and how to turn a check off honestly.
- `knowledge/tokens/` — every design token, plus the four theme override sets.
- `knowledge/components/` — one contract per component: props, variants, token bindings,
  states, anti-patterns, accessibility.
- `knowledge/snippets/` — the reviewed reference markup. This is what "correct" looks like.
- `knowledge/canon/` — canon.css and type.css, the composition layer, and the generators that
  mint them from tokens.
- `knowledge/compliance/` — which WCAG criteria apply to which component, and the rule set.
- `knowledge/_validate_*.py` — the gates. Each one in this pack was **run** outside the source
  repo before it was included; the verdicts are in `_MANIFEST.json`.
- `knowledge/_RUNBOOK-*.md` — the procedures: compose from canon, take a component through its
  gates, render and verify, write a criteria contract, onboard an existing code library.
- `showroom/` — the live library, including the foundations pages.
- `FIRST-SESSION.md` — **start here.** A guided first session with Memento: what it is in three
  sentences, then your first capture, your first ruling written through the machinery with every
  field explained, and your first wrap.
- `.github/` — the VS Code + Copilot bridge. `copilot-instructions.md` is loaded automatically
  and indexes the five skills with the phrases that should trigger each one; `prompts/` makes
  each skill a slash command. Without this the skills sit in the pack and never fire.
- `memento-package/` — **Memento — Gumdrop v1.0.0**: Memento's machinery, plus the cold start.
  The machinery is the engine this design system runs on. The record it ships is **empty on
  purpose**: an empty task store, an empty rulings store — both with the shapes already right and
  driven against those shapes before shipping — and a starter `_CHAIN.md` that explains the
  first move and is replaced the first time you wrap. Nothing in it is anyone else's history.
  Your project grows its own memory from nothing, which is the point: the shapes are machinery,
  the contents are your record. Its version line is its own — this pack's version does not move
  it, and a later Apollo release may carry the same Gumdrop or a newer cut.

## The canon generators, and one warning

The generators that mint canon from the tokens are in here, because this is the working engine
and not a baked copy of one. Changing a token and re-minting canon can produce canon that never
passed a gate. Each generator says so when you run it inside this pack and asks you to pass
`--i-understand` before it will proceed. Then run `python3 ci-template/run-gates.py` — that
is what tells you whether what you just minted still passes.

## What is deliberately NOT in here

Review files, session notes, run logs, client project work, and the licensed material we cannot
redistribute. `_MANIFEST.json` lists every exclusion with its reason.

## Gates that need something installed

A few gates drive a real browser and need `playwright`. They are included and they name their
own dependency when you run them without it — see `_MANIFEST.json` for which ones.
