# Apollo pro-forma — recurring-defect tracker

Stood up 2026-07-14 (Dave: *"we need to track this error, it keeps happening"*). Log recurring
defects here so a fix isn't just a one-off — each entry names the **root cause** and the **prevention**
(the gate that stops it recurring). A defect isn't "closed" until its prevention exists.

Format: `ID · title · symptom · root cause · fix · prevention (gate) · status`.

---

## DEF-001 — interactive-atom motion diverges from the canonical Button scale-physics
- **Symptom (Dave, T5 card):** buttons "don't scale up" on hover; "the wrong hover and pressed state on
  the button atom… it keeps happening."
- **Root cause:** the pro-forma **scaffold** `.btn` put the hover-grow only on `.btn.pri`, at a flat 2px,
  not width-derived — while the canon (`snippets/Button.reference.html`, motion promoted 2026-06-22)
  applies it to **every** variant via `.btn:hover{transform:scale(var(--hs))}` with a **width-derived
  7px grow / 9px press + brightness(.85)**, set by a `sizeScale()` JS so absolute motion is constant at
  any size. Ghost/secondary buttons therefore never grew. Systemic (shared scaffold → recurs everywhere).
- **Fix (2026-07-14):** scaffold `.btn`/`.ib` re-bound to the canonical scale-physics verbatim + the
  `sizeScale()` JS added (also covers `.card-link`). One central change → every tranche corrected.
- **Prevention (BUILT 2026-07-14 — `knowledge/_validate_state_cluster.py`, wired into `_build_all.py`):**
  gates the core cluster atoms — `.btn`/`.card-link` must bind `scale(var(--hs))`/`scale(var(--ps))`
  (never a literal/variant-only hover), `.btn`/`.ib`/`.card-link` press must be `brightness(.85)`, and
  `sizeScale()` must be wired. Scoped to those atoms so approved constant-px pops on `.ib`/`.av`/`.chip-x`/
  `.pb-action` aren't false-flagged. Self-tested: fails a literal-hover + `.94` injection. KNOWN SCOPE GAP:
  other bespoke interactive classes (e.g. T4 `.pg-num`) aren't covered — extend if that pattern recurs.
- **Status:** FIXED + GATED. Central scaffold fix now PROPAGATED to **T1 and T4** too (they were the
  un-migrated originals — flat `scale(.97)`/`.94`, hover-grow on `.btn.pri` only; the new gate caught them).
  All 6 tranches pass the state-cluster gate.

## DEF-002 — glyph invisible on a same-value surface (checkbox tick "no tick")
- **Symptom (Dave, T3):** checked checkbox shows no tick.
- **Root cause:** the tick `<symbol>` path is `fill="currentColor"`; on the checked box `currentColor`
  resolved to `--ink` (dark) sitting on the `--pri` (near-black) fill = dark-on-dark, invisible. A CSS
  `fill:` on the wrapping svg does NOT override the path's own `fill="currentColor"`.
- **Fix (2026-07-14):** set the box `color:var(--icon-rev)` when `:checked`/`:indeterminate` so
  `currentColor` becomes the reversed (light) colour; tick + dash now read on the fill.
- **Prevention (BUILT 2026-07-14 — `knowledge/_validate_glyph_presence.py`, wired into `_build_all.py`):**
  a static token-resolution check (reuses `_contrast_utils.contrast_ratio`) — for every rule that paints a
  glyph/ink on a surface (co-declared non-transparent `background:var(--Y)` + `color`/`fill:var(--X)`),
  the pair must clear **1.3:1 in BOTH themes**. Floor calibrated: every intended painted pair is ≥1.81:1;
  the bug pair `--ink` on `--pri` = 1.12:1 dark → caught. Self-tested: fails that injection. (Static
  approximation of the "render-based" ideal — covers the co-declared-surface class where the bug lives;
  transparent-surface glyphs on the inherited page are covered by the existing text/icon contrast audit.)
- **Status:** FIXED (T3) + GATED. All 6 tranches pass the glyph-presence gate.

---

*Both preventions are on the same theme as [[proforma-programme]]: a rule is only a guarantee once it's
gated. As of 2026-07-14 both gates are BUILT and wired into `_build_all.py` — DEF-001 and DEF-002 can no
longer recur silently. The exemplar held: the DEF-001 gate itself surfaced that T1/T4 were never migrated,
and the central fix was propagated to them. Next candidates if patterns recur: extend DEF-001 scope to
other bespoke interactive classes (e.g. `.pg-num`); upgrade DEF-002 from static-token to true render-based.*
