import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  CreditCard,
  BarChart2,
  Settings,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Calendar,
  Repeat,
  ArrowRight,
  ChevronRight,
  CheckCircle,
  AlertCircle,
  Clock,
  LayoutGrid,
  Send,
} from "lucide-react";

const cashData = [
  { time: "10:00", balance: 52300 },
  { time: "11:00", balance: 52800 },
  { time: "12:00", balance: 53200 },
  { time: "13:00", balance: 53900 },
  { time: "14:00", balance: 54200 },
  { time: "15:00", balance: 54600 },
  { time: "Now", balance: 54750 },
];

const transactions = [
  {
    id: 1,
    name: "Amazon Web Services",
    category: "CLOUD SERVICES",
    time: "2 HOURS AGO",
    amount: -1249.5,
    currency: "GBP",
    status: "cleared",
    type: "debit",
  },
  {
    id: 2,
    name: "Stripe Payment",
    category: "REVENUE",
    time: "5 HOURS AGO",
    amount: 8450.0,
    currency: "GBP",
    status: "cleared",
    type: "credit",
  },
  {
    id: 3,
    name: "Figma Professional",
    category: "SOFTWARE",
    time: "YESTERDAY",
    amount: -45.0,
    currency: "USD",
    status: "pending",
    type: "debit",
  },
  {
    id: 4,
    name: "Acme Corp — Invoice #2847",
    category: "REVENUE",
    time: "YESTERDAY",
    amount: 12500.0,
    currency: "GBP",
    status: "cleared",
    type: "credit",
  },
  {
    id: 5,
    name: "Salary — John Smith",
    category: "PAYROLL",
    time: "2 DAYS AGO",
    amount: -3200.0,
    currency: "GBP",
    status: "cleared",
    type: "debit",
  },
];

const upcomingPayments = [
  { day: "15", month: "MAY", name: "Amazon Business", ref: "51-29-60 · ···· 1791", amount: 450200 },
  { day: "22", month: "MAY", name: "BrightHire Payroll Ltd", ref: "14-21-65 · ···· 7851", amount: 45200 },
  { day: "22", month: "JUL", name: "HMRC — PAYE", ref: "17-82-25 · ···· 4657", amount: 2200 },
  { day: "12", month: "AUG", name: "British Gas Business", ref: "38-15-81 · ···· 3181", amount: 4200 },
  { day: "09", month: "SEP", name: "Ravenscroft Properties", ref: "57-22-80 · ···· 2028", amount: 50200 },
];

const navItems = [
  { label: "Accounts", icon: LayoutGrid },
  { label: "Payments", icon: Send },
  { label: "Cards", icon: CreditCard },
  { label: "Analytics", icon: BarChart2 },
  { label: "Settings", icon: Settings },
];

const paymentActions = [
  { label: "Make a payment", icon: ArrowUpRight, color: "bg-[#db0011]" },
  { label: "Pay a bill", icon: ArrowRight, color: "bg-[#c1440e]" },
  { label: "Move money between accounts", icon: RefreshCw, color: "bg-[#1a3c5e]" },
  { label: "Standing order", icon: Calendar, color: "bg-[#2d6a4f]" },
  { label: "Direct debit", icon: Repeat, color: "bg-[#4a4a4a]" },
];

function fmt(n: number, currency = "GBP") {
  const sym = currency === "USD" ? "$" : "£";
  return `${sym}${Math.abs(n).toLocaleString("en-GB", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtK(n: number) {
  return `£${(n / 1000).toFixed(0)}k`;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#1a1a1a] text-white text-xs px-3 py-2">
        <p className="font-semibold">£{payload[0].value.toLocaleString("en-GB")}</p>
        <p className="text-[#aaa]">{label}</p>
      </div>
    );
  }
  return null;
};

export default function App() {
  const [activeNav, setActiveNav] = useState("Payments");
  const [approvals, setApprovals] = useState([
    { id: 1, name: "Amazon Business", by: "Sarah Chen", ago: "2d ago", amount: 450.2 },
    { id: 2, name: "BrightHire Payroll Ltd", by: "Sarah Chen", ago: "2d ago", amount: 450.2 },
  ]);

  function handleApprove(id: number) {
    setApprovals((a) => a.filter((x) => x.id !== id));
  }
  function handleReject(id: number) {
    setApprovals((a) => a.filter((x) => x.id !== id));
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden font-['Inter',sans-serif] bg-[#f4f4f4]">
      {/* Sidebar */}
      <aside className="w-[200px] min-w-[200px] bg-[#1a1a1a] flex flex-col border-r border-[#2a2a2a]">
        {/* HSBC Logo */}
        <div className="px-6 py-5 border-b border-[#2a2a2a]">
          <div className="flex items-center gap-2">
            <HsbcHexagon />
            <div>
              <div className="text-white font-bold text-sm tracking-wide leading-tight">HSBC</div>
              <div className="text-[#888] text-[10px] tracking-widest uppercase leading-tight">Business</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4">
          {navItems.map(({ label, icon: Icon }) => (
            <button
              key={label}
              onClick={() => setActiveNav(label)}
              className={`w-full flex items-center gap-3 px-6 py-3 text-sm transition-colors text-left ${
                activeNav === label
                  ? "bg-[#db0011] text-white font-semibold"
                  : "text-[#aaaaaa] hover:bg-[#2a2a2a] hover:text-white"
              }`}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </nav>

        {/* User */}
        <div className="px-6 py-4 border-t border-[#2a2a2a]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#db0011] to-[#9b000c] flex items-center justify-center text-white text-xs font-bold">
              SC
            </div>
            <div>
              <div className="text-white text-xs font-semibold">Sarah Chen</div>
              <div className="text-[#888] text-[10px] uppercase tracking-wide">Admin</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        {/* Top bar */}
        <div className="bg-white border-b border-[#e0e0e0] px-8 py-0 flex items-center">
          <div className="border-b-2 border-[#db0011] py-4">
            <h1 className="text-[18px] font-semibold text-[#1a1a1a] tracking-tight">Payments</h1>
          </div>
        </div>

        <div className="p-6 space-y-5">
          {/* Payment actions */}
          <div className="bg-white border border-[#e0e0e0] p-5">
            <p className="text-[11px] font-semibold text-[#767676] uppercase tracking-widest mb-4">
              Initiate a payment
            </p>
            <div className="flex gap-8 flex-wrap">
              {paymentActions.map(({ label, icon: Icon, color }) => (
                <button
                  key={label}
                  className="flex flex-col items-center gap-2 group"
                >
                  <div className={`w-12 h-12 ${color} flex items-center justify-center text-white transition-opacity group-hover:opacity-85`}>
                    <Icon size={20} />
                  </div>
                  <span className="text-[11px] text-center text-[#333] leading-tight max-w-[80px] group-hover:text-[#db0011] transition-colors">
                    {label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Cash position */}
          <div className="bg-white border border-[#e0e0e0] p-5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-[10px] font-semibold text-[#767676] uppercase tracking-widest">Cash Position</p>
                <p className="text-[11px] text-[#767676] mt-0.5">Today · 23 April 2026</p>
              </div>
              <button className="text-[11px] text-[#db0011] font-semibold hover:underline flex items-center gap-1">
                View accounts <ChevronRight size={12} />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-6 mb-5">
              {[
                { label: "OPENING BALANCE", value: "£52,300", color: "text-[#1a1a1a]" },
                { label: "CURRENT BALANCE", value: "£54,750", color: "text-[#1a1a1a]" },
                { label: "NET MOVEMENT", value: "+£2,450", color: "text-[#2d6a4f]" },
                { label: "EST. CLOSING", value: "£55,100", color: "text-[#1a1a1a]" },
              ].map(({ label, value, color }) => (
                <div key={label}>
                  <p className="text-[10px] font-semibold text-[#767676] uppercase tracking-widest mb-1">{label}</p>
                  <p className={`text-[22px] font-semibold ${color} tracking-tight`}>{value}</p>
                </div>
              ))}
            </div>

            <div className="h-[130px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={cashData} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="cashGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#db0011" stopOpacity={0.12} />
                      <stop offset="95%" stopColor="#db0011" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="time"
                    tick={{ fontSize: 10, fill: "#767676" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis hide domain={["auto", "auto"]} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="balance"
                    stroke="#db0011"
                    strokeWidth={2}
                    fill="url(#cashGrad)"
                    dot={false}
                    activeDot={{ r: 4, fill: "#db0011", strokeWidth: 0 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="border border-[#e0e0e0] p-3">
                <p className="text-[10px] text-[#767676] uppercase tracking-widest mb-1">Inflows</p>
                <p className="text-[18px] font-semibold text-[#2d6a4f]">+£11,650</p>
              </div>
              <div className="border border-[#e0e0e0] p-3">
                <p className="text-[10px] text-[#767676] uppercase tracking-widest mb-1">Outflows</p>
                <p className="text-[18px] font-semibold text-[#db0011]">−£9,200</p>
              </div>
            </div>

            <div className="mt-3 bg-[#f0f7f3] border-l-4 border-[#2d6a4f] px-4 py-3 flex items-start gap-2">
              <CheckCircle size={14} className="text-[#2d6a4f] mt-0.5 shrink-0" />
              <div>
                <p className="text-[11px] font-semibold text-[#2d6a4f] uppercase tracking-wide">You're covered</p>
                <p className="text-[11px] text-[#333] mt-0.5 leading-relaxed">
                  Operating — Main has enough to clear all scheduled payments through May with £42k buffer.
                </p>
              </div>
            </div>
          </div>

          {/* Transactions */}
          <div className="bg-white border border-[#e0e0e0]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#e0e0e0]">
              <p className="text-[11px] font-semibold text-[#767676] uppercase tracking-widest">Transactions</p>
              <button className="text-[11px] text-[#db0011] font-semibold hover:underline flex items-center gap-1">
                View all <ChevronRight size={12} />
              </button>
            </div>
            <div className="divide-y divide-[#f0f0f0]">
              {transactions.map((tx) => (
                <div key={tx.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-[#fafafa] transition-colors">
                  <div
                    className={`w-8 h-8 flex items-center justify-center shrink-0 ${
                      tx.type === "credit" ? "bg-[#f0f7f3]" : "bg-[#fde8ea]"
                    }`}
                  >
                    {tx.type === "credit" ? (
                      <ArrowDownLeft size={14} className="text-[#2d6a4f]" />
                    ) : (
                      <ArrowUpRight size={14} className="text-[#db0011]" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-[13px] font-semibold text-[#1a1a1a] truncate">{tx.name}</p>
                      {tx.status === "cleared" ? (
                        <CheckCircle size={12} className="text-[#2d6a4f] shrink-0" />
                      ) : tx.status === "pending" ? (
                        <Clock size={12} className="text-[#f4a261] shrink-0" />
                      ) : (
                        <AlertCircle size={12} className="text-[#db0011] shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-[#767676] uppercase tracking-wide mt-0.5">
                      {tx.category} · {tx.time}
                    </p>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-[13px] font-semibold ${
                        tx.amount > 0 ? "text-[#2d6a4f]" : "text-[#1a1a1a]"
                      }`}
                    >
                      {tx.amount > 0 ? "+" : "−"}{fmt(tx.amount, tx.currency)}
                    </p>
                    {tx.currency !== "GBP" && (
                      <p className="text-[10px] text-[#767676]">{tx.currency}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Right panel */}
      <aside className="w-[300px] min-w-[300px] bg-white border-l border-[#e0e0e0] overflow-y-auto">
        {/* Pending approvals */}
        {approvals.length > 0 && (
          <div className="border-b border-[#e0e0e0]">
            <div className="bg-[#fde8ea] border-b border-[#f5c0c5] px-5 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle size={14} className="text-[#db0011]" />
                <span className="text-[12px] font-semibold text-[#db0011]">Pending your approval</span>
              </div>
              <button className="text-[11px] text-[#db0011] font-semibold hover:underline">View all</button>
            </div>
            {approvals.map((a) => (
              <div key={a.id} className="px-5 py-4 border-b border-[#f0f0f0] last:border-0">
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <p className="text-[13px] font-semibold text-[#1a1a1a]">{a.name}</p>
                    <p className="text-[11px] text-[#767676] mt-0.5">{a.by} · {a.ago}</p>
                  </div>
                  <p className="text-[13px] font-semibold text-[#1a1a1a]">£{a.amount.toLocaleString()}</p>
                </div>
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => handleApprove(a.id)}
                    className="flex-1 bg-[#db0011] text-white text-[12px] font-semibold py-2 hover:bg-[#b8000e] transition-colors"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => handleReject(a.id)}
                    className="flex-1 border border-[#db0011] text-[#db0011] text-[12px] font-semibold py-2 hover:bg-[#fde8ea] transition-colors"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Upcoming payments */}
        <div>
          <div className="px-5 py-4 border-b border-[#e0e0e0]">
            <div className="flex items-center justify-between">
              <p className="text-[12px] font-semibold text-[#1a1a1a]">Upcoming payments</p>
              <button className="text-[11px] text-[#db0011] font-semibold hover:underline">View all</button>
            </div>
            <p className="text-[11px] text-[#767676] mt-0.5">10 scheduled · 250,000 GBP total</p>
          </div>
          <div className="divide-y divide-[#f0f0f0]">
            {upcomingPayments.map((p, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-3.5 hover:bg-[#fafafa] transition-colors">
                <div className="text-center w-10 shrink-0">
                  <p
                    className={`text-[16px] font-bold leading-tight ${
                      i === 0 ? "text-[#db0011]" : "text-[#1a1a1a]"
                    }`}
                  >
                    {p.day}
                  </p>
                  <p className="text-[9px] font-semibold text-[#767676] uppercase tracking-wide">{p.month}</p>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[12px] font-semibold text-[#1a1a1a] truncate">{p.name}</p>
                  <p className="text-[10px] text-[#767676] mt-0.5 font-mono">{p.ref}</p>
                </div>
                <p className="text-[12px] font-semibold text-[#1a1a1a] whitespace-nowrap">
                  £{p.amount.toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

function HsbcHexagon() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="28" height="28" fill="#DB0011" />
      <path d="M14 5L14 23M5 14L23 14" stroke="white" strokeWidth="2.5" />
      <path d="M8 8L20 20M20 8L8 20" stroke="white" strokeWidth="1.2" opacity="0.5" />
    </svg>
  );
}
