
  # HSBC Style Redesign

  This is a code bundle for HSBC Style Redesign. The original project is available at https://www.figma.com/design/vU4QlGTX1pyzjhl75WZwbS/HSBC-Style-Redesign.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  